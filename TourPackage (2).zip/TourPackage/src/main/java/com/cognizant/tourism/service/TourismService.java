package com.cognizant.tourism.service;

import java.util.List;

import com.cognizant.tourism.entity.Tourism;
import com.cognizant.tourism.entity.UserManage;

public interface TourismService {
	void addEntry(Tourism entry);
	List<Tourism> listEntries();
	Tourism getEntryById(int id);
	void deleteEntry(int id);
	List<UserManage> listOfUsers();
	List<Tourism> getResultList(String fromLocation,String toLocation);
}
